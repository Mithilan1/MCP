#!/usr/bin/env bash
# ============================================================
# Claude Code — Skills Setup Script
# Assignment 4 — AIDI 2001
# Installs all 5 required skills from mattpocock/skills
# ============================================================

set -e

echo "Installing required skills for Claude Code..."

npx skills@latest add mattpocock/skills/grill-me
npx skills@latest add mattpocock/skills/write-a-prd
npx skills@latest add mattpocock/skills/prd-to-issues
npx skills@latest add mattpocock/skills/tdd
npx skills@latest add mattpocock/skills/improve-codebase-architecture

echo ""
echo "All 5 skills installed successfully."
echo "Run 'claude skills list' to verify."
