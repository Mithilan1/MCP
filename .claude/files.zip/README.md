# Assignment 4 — Claude Section
## AIDI 2001 | MCP Setup & Skills Setup

---

## Overview

This document covers the **Claude Code** portion of Assignment 4:

- **Part 1** — MCP Server Setup (Context7, NotebookLM, Playwright)
- **Part 2** — Skills Setup (grill-me, write-a-prd, prd-to-issues, tdd, improve-codebase-architecture)

---

## Part 1 — MCP Setup in Claude Code

### Config file location

Claude Code reads MCP server config from `.mcp.json` in your project root (or globally from `~/.claude/mcp.json`).

### Config (`.mcp.json`)

```json
{
  "mcpServers": {
    "context7": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    },
    "notebooklm": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@google/notebooklm-mcp@latest"],
      "env": {
        "GOOGLE_API_KEY": "${GOOGLE_API_KEY}"
      }
    },
    "playwright": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest"]
    }
  }
}
```

### Setup steps

1. Place `.mcp.json` in the root of your project (or `~/.claude/` for global use).
2. Add any required API keys to your environment (see `.env.example` below).
3. Start Claude Code — it will automatically detect and connect the MCP servers.
4. Verify with `/mcp` in Claude Code to list connected servers.

### Environment variables (`.env.example`)

```env
GOOGLE_API_KEY=your_google_api_key_here
```

> Keep this file as `.env.example` — never commit your real `.env` to git.

---

### MCP Server Descriptions

#### Context7
**Purpose:** Provides up-to-date, version-specific documentation for any library directly into Claude's context.

**Install command:**
```bash
npx -y @upstash/context7-mcp@latest
```

**Example usage in Claude Code:**
```
Use context7 to get the latest docs for React 19 hooks.
```

---

#### NotebookLM
**Purpose:** Lets Claude interact with your Google NotebookLM notebooks — query sources, generate summaries, and pull research notes into your coding workflow.

**Install command:**
```bash
npx -y @google/notebooklm-mcp@latest
```

**Requires:** `GOOGLE_API_KEY` environment variable.

**Example usage in Claude Code:**
```
Search my NotebookLM for notes about API design patterns.
```

---

#### Playwright
**Purpose:** Gives Claude the ability to control a real browser — navigate pages, click elements, fill forms, take screenshots, and run end-to-end tests.

**Install command:**
```bash
npx -y @playwright/mcp@latest
```

**Example usage in Claude Code:**
```
Use Playwright to open http://localhost:3000 and verify the login form renders.
```

---

## Part 2 — Skills Setup in Claude Code

### What are skills?

Skills are reusable prompt workflows stored in your `.claude/skills/` directory. Claude Code picks them up automatically and you invoke them with `/skill-name`.

### Installation

Run the install script (requires Node.js):

```bash
bash install-skills.sh
```

Or install each skill individually:

```bash
npx skills@latest add mattpocock/skills/grill-me
npx skills@latest add mattpocock/skills/write-a-prd
npx skills@latest add mattpocock/skills/prd-to-issues
npx skills@latest add mattpocock/skills/tdd
npx skills@latest add mattpocock/skills/improve-codebase-architecture
```

After installation, skills live at:
```
.claude/
  skills/
    grill-me/
    write-a-prd/
    prd-to-issues/
    tdd/
    improve-codebase-architecture/
```

---

### Skills Reference

#### 1. `grill-me`
**Purpose:** Relentlessly interviews you about your plan until every decision branch is resolved. Forces you to think through edge cases before writing code.

**When to invoke:** Before writing a PRD or starting any feature — use this to stress-test your thinking.

**How to invoke:**
```
/grill-me
```

**What it does:**
- Asks probing questions about your plan one at a time
- Explores the codebase to verify your assumptions
- Keeps going until every branch of the decision tree is resolved
- Helps you reach a shared understanding with the AI before committing to an approach

---

#### 2. `write-a-prd`
**Purpose:** Creates a full Product Requirements Document through a structured interview and codebase exploration, then files it as a GitHub Issue.

**When to invoke:** After `grill-me`, once you have a clear plan.

**How to invoke:**
```
/write-a-prd
```

**What it produces:**
- Problem statement (from the user's perspective)
- Solution description
- Extensive numbered list of user stories (`As a <role>, I want <feature>, so that <benefit>`)
- Implementation decisions
- Testing decisions
- Out-of-scope items
- Submitted as a GitHub Issue in your repo

---

#### 3. `prd-to-issues`
**Purpose:** Takes your PRD and converts it into a Kanban board of independently workable GitHub Issues.

**When to invoke:** After `write-a-prd` has produced a PRD issue.

**How to invoke:**
```
/prd-to-issues
```

**What it produces:**
- Individual GitHub Issues — each one a thin vertical slice through all integration layers
- Blocking relationships between issues (dependency map)
- Issues structured so parallel agents can pick them up independently

---

#### 4. `tdd`
**Purpose:** Builds features or fixes bugs using a strict red-green-refactor loop. One vertical slice at a time.

**When to invoke:** When implementing each GitHub Issue produced by `prd-to-issues`.

**How to invoke:**
```
/tdd
```

**What it does:**
- Writes a failing test first (red)
- Writes the minimal code to make it pass (green)
- Refactors for clarity and structure (refactor)
- Includes philosophy on mocking, deep modules, and what makes a good test boundary
- Builds only external-behavior tests (not implementation details)

---

#### 5. `improve-codebase-architecture`
**Purpose:** Explores your codebase looking for structural confusion and proposes concrete improvements to module depth and cohesion.

**When to invoke:** Weekly, or after a burst of development.

**How to invoke:**
```
/improve-codebase-architecture
```

**What it does:**
- Identifies concepts that require bouncing between too many small files
- Finds pure functions extracted only for testability (where real bugs hide in their callers)
- Spots tightly coupled modules that create integration risk
- Presents "deepening opportunities" — candidates to become deep, testable modules
- Outputs a prioritized list of refactoring suggestions

---

## Recommended Workflow

Use the skills in this order for each feature:

```
1. /grill-me                        → challenge and clarify the plan
2. /write-a-prd                     → formalize into a PRD (filed as GitHub Issue)
3. /prd-to-issues                   → break PRD into individual GitHub Issues
4. /tdd                             → implement each issue with red-green-refactor
5. /improve-codebase-architecture   → review and improve structure after implementation
```

---

## Checklist

- [x] `.mcp.json` configured for Claude Code with Context7, NotebookLM, Playwright
- [x] API key management documented (env variable pattern)
- [x] All 5 skills install commands documented
- [x] Each skill's purpose, invocation, and output described
- [x] Workflow order documented

---

## References

- Skills repo: https://github.com/mattpocock/skills
- Context7 MCP: https://github.com/upstash/context7
- Playwright MCP: https://github.com/microsoft/playwright-mcp
- Claude Code docs: https://docs.anthropic.com/claude-code
